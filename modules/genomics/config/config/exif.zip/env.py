import errno
import datetime
import os
import os.path

DEST_BUCKET    = os.getenv("DEST_BUCKET")
SRC_BUCKET     = os.getenv("SRC_BUCKET")
